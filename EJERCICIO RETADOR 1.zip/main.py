#EJERCICIO RETADOR #1

superficie_km2 = int(57365)
tipo_climas = ["cálido","subhúmedo","seco","semiseco"]
temperaturamediaanual_centigrados = float(25.45)
Precipitacionpromedioanual_milimetros = float(790.1)
poblacion_mujeres = int(1532128)
poblacion_hombres = int(1494815)
ciudades = ["culiacan","mazatlan"]
porcentaje_habitantes_culiacán = float(0.3315*100)
porcentaje_habitantes_mazatlán = float(0.1657*100)
poblacion_total = (poblacion_hombres + poblacion_mujeres)
print(poblacion_total)
porcentaje_total = (porcentaje_habitantes_culiacán + porcentaje_habitantes_mazatlán)
print(porcentaje_total)