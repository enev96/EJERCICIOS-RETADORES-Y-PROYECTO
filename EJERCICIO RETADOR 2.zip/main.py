#EJERCICIO RETADOR 2

lista_municipios = []
lista_numerohab = []

municipio1_user = input("ingresa el nombre del municipio 1: ")
lista_municipios.append(municipio1_user)
numerohab1_user = int(input("ingresa la cantidad de habitantes: "))
lista_numerohab.append(numerohab1_user)

municipio2_user = input("ingresa el nombre del municipio 2: ")
lista_municipios.append(municipio2_user)
numerohab2_user = int(input("ingresa la cantidad de habitantes: "))
lista_numerohab.append(numerohab2_user)

municipio3_user = input("ingresa el nombre del municipio 3: ")
lista_municipios.append(municipio3_user)
numerohab3_user = int(input("ingresa la cantidad de habitantes: "))
lista_numerohab.append(numerohab3_user)


suma_habitantes = sum (lista_numerohab)
print("El total de habitantes es: " + str(suma_habitantes))

cantidad_municipios = len(lista_municipios)
promedio_habitantes = suma_habitantes / cantidad_municipios
print("El promedio de habitantes es: " + str(promedio_habitantes))


#ALTERNATIVA2 PARA OBTENER LA CANTIDAD TOTAL DE HABITANTES
#suma_habitantes = 0
#for habitantes in lista_numerohab:
  #suma_habitantes += habitantes
  #print(suma_habitantes)