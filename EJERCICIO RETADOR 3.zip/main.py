#EJERCICIO RETADOR #3

Capacidad_kg = int(3254)
pesocemento_kg = int(40)
pesoyeso_kg= int(30)

totalsacos_yeso = int(input("Numero de costales de yeso (kg): "))
totalsacos_cemento = int(input("Numero de costales de cemento (kg): "))

peso_total = (totalsacos_cemento*pesocemento_kg) + (totalsacos_yeso*pesoyeso_kg)

print("El peso total en kg es de : "+ str(peso_total)+ " Kg")

autorizacion_envio = peso_total <= Capacidad_kg
print("¿El envio se puede realizar?: " + str(autorizacion_envio)) 

