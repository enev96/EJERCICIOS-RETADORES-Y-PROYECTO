#EJERCICIO RETADOR NUMERO #4

ID_producto = ["1","2","3"]
Tipo_producto = ["Maíz Grano","Pepino","Tomate Verde"]
lista_costos = ["285.55","334.72","129.00"]

total_cajas = int(input("Numero de cajas a vender: "))
seleccion_ID = input ("ID del producto: ")

nombre_producto = Tipo_producto[ID_producto.index(seleccion_ID)]
print("El producto es: "+ nombre_producto)

costo_caja = lista_costos[ID_producto.index(seleccion_ID)]
print("El precio por caja es: $ "+ costo_caja)

costo_total = float(costo_caja)*(total_cajas)
print("El costo total a pagar  es: $ " + str(round(costo_total,3)))
  
