#EJERCICIO INTEGRADOR PARTE1

lista_productos = [["Maíz Grano",285.55],["Pepino",334.72],["Tomate Verde",129.00]]
venta_productos = [
[2, 122],
[1, 89],
[1, 22],
[3, 48],
[1, 75],
[3, 322],
[2, 95],
[1, 148],
[1, 83],
[3, 100]
]


total_cajas = int(input("Numero de cajas a vender: "))
id_producto = input("ID del producto: ")
monto_decuento = int(1500)
ventas_diarias = int(1104)
venta_total = ventas_diarias + total_cajas
descuento = venta_total > monto_decuento


if  id_producto == "1":
  print("El producto es: ", lista_productos[0][0])
  print("El precio por caja es : $ ", lista_productos[0][1])
  print("Aplica descuento del 20%:", descuento)
  if descuento:
    print("El costo total a pagar: $ ", (lista_productos[0][1] * total_cajas)*(0.80))
  else:
    print("El costo total a pagar: $ ", (lista_productos[0][1] * total_cajas))
    
elif  id_producto == "2":
  print("El producto es: ", lista_productos[1][0])
  print("El precio por caja es : $ ", lista_productos[1][1])
  print("Aplica descuento del 20%:", descuento)
  if descuento:
    print("El costo total a pagar:", (lista_productos[1][1] * total_cajas)*(0.80))
  else:
    print("El costo total a pagar: $ ", (lista_productos[1][1] * total_cajas))

elif  id_producto == "3":
  print("El producto es: ", lista_productos[2][0])
  print("El precio por caja es : $ ", lista_productos[2][1])
  print("Aplica descuento del 20%:", descuento)
  if descuento:
    print("El costo total a pagar:", (lista_productos[2][1] * total_cajas)*(0.80))
  else:
    print("El costo total a pagar: $ ", (lista_productos[2][1] * total_cajas))
    

 
 
  